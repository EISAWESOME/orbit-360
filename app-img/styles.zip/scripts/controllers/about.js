'use strict';

/**
 * @ngdoc function
 * @name orbitApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the orbitApp
 */
angular.module('orbitApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
